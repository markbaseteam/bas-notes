Click anything on the sidebar :)

Cool Stuff to look out for:
- NuShell