---
tags: note
---
>[!abstract] Definitie
>Stel $f$ is een functie met als domein de verzameling $X$. De functie is [[Injectie|injectief]] als voor alle $a,b \in X$, als $f(a)=f(b)$ dan $a=b$

>[!abstract] Definitie
>$\forall a,b \in X, f(a)=f(b) \Rightarrow a=b$