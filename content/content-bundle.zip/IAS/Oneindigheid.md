---
tags: note
---
Er zijn oneindigveel verschillende oneindigheden:
- $\aleph_{0}$ "Aleph nul" is aftelbaar oneindig, dus $|\mathbb{N}|$
- $\aleph_{1}$ "Aleph één" is hetzelfde als $_{CH}|\mathbb{R}|$
- En zo heb je oneindig veel oneindigheden

>[!abstract] Definitie
>Een verzameling heet [[Aftelbaar]] als deze op een (mogelijk oneindige) rij kan worden gezet.

>[!abstract] Definitie
>Een oneindige verzameling die niet aftelbaar is noemen we [[Overaftelbaar]].
>