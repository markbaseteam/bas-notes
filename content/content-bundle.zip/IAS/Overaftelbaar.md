---
tags: note
---
>[!abstract] Definitie
>Een oneindige verzameling die niet aftelbaar is noemen we [[Overaftelbaar]].

Gerelateerd: [[Oneindigheid]], [[Aftelbaar]]