---
tags: lecture
week: Week 2
---
### Berekenbaarheid
##### Onberekenbaarheid van functies
>[!note] Stelling
>Bijna alle functies van N naar N zijn niet [[Berekenbaarheid|berekenbaar]]

##### Bewijs
- $\mathbb{N}^{N}$ is [[Overaftelbaar|overaftelbaar]]
- De verzameling van alle computerprogramma's is "slechts" [[Aftelbaar|aftelbaar]]
---
##### Expliciete constructie van onberekenbare functie N naar N
Laat $h: Strings \rightarrow 0,1$ de halting-functie zijn.
We weten dat deze niet [[Berekenbaarheid|berekenbaar]] is.
Laat:
- $g: Strings \rightarrow \mathbb{N}$ de [[Gödel-nummering|Gödelfunctie]] zijn.
- $g^{-1}: \mathbb{N} \rightarrow Strings \cup undef$
Beiden functies zijn berekenbaar
Dus de functie $k = hog^{-1}$ is niet berekenbaar

---
##### Expliciete constructie van een onberekenbaar reëel getal
Laat $P_1,P_2,P_3,P_4,...$ een aftelling van invoerloze computerprogramma's zijn.
Laat $0,1,0,1,1,\dots$ de corresponderende stop-string zijn:
- Bit 1: stopt
- Bit 2: stopt niet
Dan is $k= 0.10110110110111101...$ niet berekenbaar
---
### Fractals
##### Zelf-gelijkvormigheid
Een figuur die is opgebouwd uit onderdelen met dezelfde vorm
>[!col]
>De hersenen zijn ook een voorbeeld van een fractal
>
>![[Pasted image 20230220113432.png]]
<details> <summary>Voorbeeld in de natuur</summary> <ul><li>Varens in de natuur hebben allemaal dezelfde vorm</li><li>Kust van Engeland</li><li>In het lichaam zitten ook zichzelf-aanpassende fractals</li></ul> </details>

---
##### Waarom fractals bestuderen?
Inzien dat complexe structuren gevormd kunnen worden met behulp van eenvoudige elementen.
Verschillende velden:
- **Biologie**: schelpen, bladeren, bomen, longen, hersenen.
- **Planologie**: plannen van wijken en wegen.
- **Architectuur**: structuralisme.
- **Game design**: het genereren van kunstmatige landschappen.
---
##### Genereermethoden
Er zijn verschillende methoden om afbeeldingen te genereren:
Met turtles:
- Door één turtle een eenvoudige tekenprocedure mee te geven en dan te klonen (je krijgt dan meerdere turtles)
  ![[Pasted image 20230220113758.png|500]]
- Door één turtle een recursieve tekenprocedure mee te geven
  ![[Pasted image 20230220113845.png]]

Zonder turtles:
- [[Iterated Function Systems|Iterated Functions Systems (IFS) of ookwel Multiple-Reduction Copy Machines (MRCM)]]
- [[Escape Time Fractals]]
---
##### [[Koch curve]] d.m.v [[L-systeem]]
>[!note] Herschrijfregel
>$F \rightarrow F + F --F+F$
- +: draai +60 graden
- -: draai -60 graden
![[Pasted image 20230220114432.png]]
---
##### [[Hausdorff-dimensie]]
![[Pasted image 20230220114629.png]]
