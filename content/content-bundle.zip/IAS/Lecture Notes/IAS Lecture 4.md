---
tags: lecture
---
#### Adaptieve Fractals
##### Fractals door verkleind kopiëren
<details> <summary> De Multiple Reduction Copy Machine</summary> <ul><li>Een afbeelding meervoudig verkleind kopiëren.</li><li>Officiële naam: Iterated Function Systems</li><li>Het is zoals een kopieermachine met drie lenzen</li><li>Idee: verklein en draai een afbeelding op een vast aantal verschillende manieren en herhaal dit</li></ul></details>
Één contractie, die contraheerd naar één dek punt (fixed point). De afbeelding verdwijnt dus altijd naar één stip, dit is niet heel spannend

Twee contracties, de afbeelding wordt verveelvoudigd en de verveelvoudigingen worden verkleint. Dit soort contracties hebben geen dekpunt meer, wel hebben ze een gebied waar alles naar toe wordt gezien (”basin of attraction”)

Drie contractie resulteert altijd in de [[Driehoek van Sierpinksi|driehoek van Sierpinksi]].

---
##### Transformaties met matrices
![[Pasted image 20230220145602.png]]

---
##### [[Iterated Function Systems]]
Er zijn twee manieren van IFS'en:
- *Deterministisch*: doe op het hele domein één iteratie van alle contracties en herhaa;
- *Stochastisch*: doe op één willekeurig punt, zeg 100, iteraties van steeds één willekeurige contractie. Gooi de eerste 99 benaderingen weg en plot de 100ste benadering en herhaal.
---
##### [[Contractie]]
>[!abstract] Definitie
>Een contractie is een afbeelding $f$ van een [[Metrische Ruimte|metrische ruimte]] $X$ naar zichzelf, zodanig dat er een $x\leq c\leq 1$ bestaat, zodat voor elk tweetal elementen $x,y \in X$ geldt dat $d(f(x),f(y)\leq c\cdot d(x,y)$

Afbeelding is in ons geval een lineaire afbeelding
$d(f(x),f(y))\leq c\cdot d(x,y)$: het beeld moet zijn gekrompen
De contractiefactor $c$ bepaalt hoe snel het beeld minstens moet krimpen

---
##### Fractals en Adaptiviteit
Fractal:
- één idee
- dat idee verkleind herhalen
Adaptieve fractal:
- één idee
- dat idee, in dien mogelijk, en afhankelijk van de omstandigheden, verkleind herhalen.