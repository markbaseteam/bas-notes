---
tags: lecture
---

### De examinering
- Elke vrijdag twee mini-toetsen
	-  Tellen voor 20% mee
	-  Ze worden ter plekke gemaakt
- Twee schriftelijke toetsen
	-  Deeltoets één --> 40%
	-  Deeltoets twee --> 40%

### Gary Flake
Hij schreef het boek The Computational Beauty of Nature, omdat hij altijd een boek wilde hebben die alle onderwerpen in één boek behandelden, genoeg informatie gaf om the computer programma's te kunnen dupliceren en ook genoeg motivatie gaf om de meer fundamentele gedachtes te verkennen

Zijn doel groep, van wat Flake zelf zegt, is zijn 15-jarige zelf. Dat is alleen wel erg jong voor een boek als dit, dus Gerardje denkt dat het ongeveer om 18-20 jarige ging.

>[!info] Flake's hypothese
>Complex gedarg op samengesteld niveau in grote natuurkundige, biologische, economische of sociologische systemen, lijkt te worden veroorzaakt door (zeer) eenvoudig gedrag op individueel niveau.
