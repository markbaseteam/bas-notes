---
tags: note
---
>[!abstract] Definitie
>Een verzameling getallen $X \subseteq \mathbb{N}$ heet [[Beslisbaarheid|beslisbaar]], als er een computerprogramma bestaat dat voor alle getallen in $\mathbb{N}$ kan beslissen of het in $X$ zit.

Gerelateerd: [[Semi-beslisbaarheid]]
