---
tags: note
---
>[!abstract] Definitie
>Een manier om een [[Berekenbaarheid|berekenbare]] [[Bijectie|bijectie]] te definiëren tussen $\mathbb{N}$ en Strings