---
tags: note
---
>[!abstract] Definitie
>Een verzameling getallen $X \subseteq \mathbb{N}$ heet [[Semi-beslisbaarheid|semi-beslisbaar]], als er een computerprogramma bestaat dat voor alle getallen in $X$ kan beslissen of het in $X$ zit.
>
>Voor getallen buiten $X$ geeft zo'n programma niet noodzakelijk een uitsluitsel.

Gerelateerd: [[Beslisbaarheid]]