---
tags: note
---
![[Pasted image 20230220145158.png]]
>[!info] [[Hausdorff-dimensie]] van [[Driehoek van Sierpinksi]]
>$d=\frac{log(3)}{log(2)}\approx 1.585$

