---
tags: note
---
>[!abstract] Definitie
>Stel functie $f: X \rightarrow Y$ is [[Surjectie|surjectief]] als voor elke $y \in Y$ er tenminste één $x \in X$ bestaat waarvoor $f(x)=y$.

>[!abstract] Definitie
>Als $f: X \rightarrow Y$, dan is $f$ [[Surjectie|surjectief]] als: $\forall y \in Y, \exists x \in X \Rightarrow f(x)=y$