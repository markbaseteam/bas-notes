---
tags: note
---
>[!abstract] Definitie
>$A \leq B$ en $B \leq A \Rightarrow A \sim B$ 

>[!note] Notatie
>$A \sim B \Leftrightarrow_{Def} A$ en $B$ zijn [[Gelijkmachtigheid|gelijkmachtig]] 

>[!note] Notatie
>$A \leq B \Leftrightarrow_{Def}$ er bestaat een [[Injectie]] van $A$ naar $B$.

Voorbeeld van het gebruik van de [[Stelling van Schröder-Bernstein]]:
Bewijs dat $[0,2]$ en $[0,1)$ gelijkmachtig zijn:
- Een [[Injectie]] van $[0,2]$ naar $[0,1)$ is: $x \mapsto \frac{x}{2}$
- Een [[Injectie]] van $[0,1)$ naar $[0,2]$ is: $x \mapsto x$