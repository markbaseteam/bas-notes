---
tag: note
---
>[!abstract] Definitie
>$2^A =_{def}$ de verzameling van alle deelverzameling van $A$.

>[!tip] Voorbeeld
>$2^{\{a,b,c\}} = \{\emptyset,\{a\},\{b\},\{c\},\{a,b\},\{a,c\},\{b,c\},\{a,b,c\}\}$

