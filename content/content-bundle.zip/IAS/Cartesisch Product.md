---
tags: note
---
>[!abstract] Definitie
>Het [[Cartesisch Product]] van de twee verzameling $A$ en $B$ wordt genoteerd als $A \times B$ en is gedefinieerd als een verzameling koppels: $A \times B = \{(a,b) | a \in A, b\in B\}$
