---
tags: note
---
>[!abstract] Definitie
> Een L-systeem of Lindenmayer system is een paralel herschrijfsysteem en een type van formele grammatica. L-systemen worden gedefinieerd als de volgende tuple: $G=(V,\omega,P)$. $V$ is een verzameling symbolen die zowel elementen bevat die kunnen worden vervangen (variabelen) als elementen die niet kunnen worden vervangen ("constanten" of "terminals").  $\omega$ is een reeks symbolen uit $V$ die de begintoestand van het systeem definieert. En $P$ is een reeks productieregels of producties die bepalen hoe variabelen kunnen worden vervangen door combinaties van constanten en andere variabelen. Een productie bestaat uit twee reeksen, de voorganger en de opvolger. Voor elk symbool $A$ dat lid is van de verzameling $V$ en dat niet voorkomt aan de linkerkant van een productie in $P$, wordt de identiteitsproductie $A → A$ aangenomen; deze symbolen worden constanten of terminals genoemd.
> 
