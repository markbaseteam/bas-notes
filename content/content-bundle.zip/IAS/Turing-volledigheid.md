---
tags: note
---
>[!abstract] Definitie
>Als een notie van berekening $B$ minstens even krachtig is als bekende, onderling equivalente, noties van berekeningen (zoals de Turing-machine, recursieve functies, ...) dan noemen we $B$ [[Turing-volledigheid|Turing-volledig]].

Gerelateerd: [[Alan Turing]]