---
tags: note
---
>[!abstract] Definitie
>Fractals gegenereerd door het itereren een formule op elke punt in een gegeven ruimte. 

>[!tip] Voorbeeld
>Een voorbeeld van een escape time fractal is de mandelbröt set.
>Dit is een verzameling met complexe waarden gegenereet door de formule op elk punt c: $z\rightarrow z^2+c,z_0=0$

