---
tags: note
---
>[!abstract] Definitie
>Een verzameling getallen $X \subseteq \mathbb{N}$ heet [[Complementair opsombaarheid|complementair opsombaar]] als er een computerprogramma bestaat dat alle elementen van $\mathbb{N}$ die <ins>niet</ins> in $X$ zitten (vroeg of laat) afdrukt.

Gerelateerd: [[Opsombaarheid]]