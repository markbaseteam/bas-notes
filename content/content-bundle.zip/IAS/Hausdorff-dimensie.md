---
tags: note
---
>[!abstract] Definitie
>De hausdorff-dimensie is een niet negatief reëel getal definieerd als:
>$d=-\\lim_{ r \to 0 } \frac{\log(N(r))}{\log(r)r}$ ofwel $d = \frac{\log(m)}{\log(v)}$, waarin $m$ de multipliciteit is en $v$ de verkleiningsfactor

![[Pasted image 20230220115045.png]]


