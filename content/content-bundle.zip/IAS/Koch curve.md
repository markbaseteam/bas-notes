---
tags: note
---
![[Pasted image 20230220115737.png]]
>[!info] [[Hausdorff-dimensie]] van [[Koch curve]]
>$d=\frac{log(4)}{log(3)}\approx 1.26$

