---
tags: note
---
>[!abstract] Definitie
>Een (mogelijk partiële) functie $f: \mathbb{N} \rightarrow \mathbb{N}$ heet berekenbaar, als er een computerprogramma bestaat dat $f$ kan berekenen voor precies alle getallen waarvoor $f$ is gedefinieerd.