---
tags: note
---
- 23 juni 1912 geboren in Londen
- 1931-1934 kwantummechanica, al snel wiskunde aan de Universiteit van Cambridge
- 1935: maakt kennis met het Entscheidungsproblem
- Hij maakte de Turing-machine
- WW2: Government Code en Cypher School
- 1950: Turing test
- 1954: overleden aan cyanide-vergiftiging