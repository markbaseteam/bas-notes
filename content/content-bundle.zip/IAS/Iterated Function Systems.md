---
tags: note
---
>[!abstract] Definitie
>Een [[Iterated Function Systems|iterated function system]] is een eindige verzameling van [[Contractie|contractie]] mappings op een [[Metrische Ruimte|metrische ruimte]]. Symbolische is het zo gedefinieerd: $\{f_1:X\rightarrow X|i=1,2,...,N\}, N\in \mathbb{N}$, wat een iterated function system is als elke $f_i$ een [[Contractie|contractie]] is op de [[Metrische Ruimte|metrische ruimte]] $X$.
