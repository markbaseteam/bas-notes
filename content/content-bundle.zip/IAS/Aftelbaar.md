---
tags: note
---

>[!abstract] Definitie
>Een verzameling heet [[Aftelbaar]] als deze op een (mogelijk oneindige) rij kan worden gezet.

>[!abstract] Wiskundige definitie
>Een verzameling $A$ heet [[Aftelbaar]] als er een [[Surjectie]] $f: \mathbb{N} \rightarrow A$ bestaat.

>[!abstract] Wiskundige definitie
>Een verzameling $A$ heet [[Aftelbaar]] als er een [[Injectie]] $f: A \rightarrow \mathbb{N}$

Voorbeelden van aftelbare verzameling zijn:
- De verzameling $\mathbb{N}$
- De verzameling $\mathbb{Z} = 0,1,-1,2,-2,3,-3,\dots$
- De verzameling van algebraïsche getallen (oplossing van veeltermen), $\mathbb{A}$
- De verzameling van alle C#-programma's
- De verzameling van alle Netlogo-programma's
- De verzameling <ins>alle</ins> computer-programma's
- De verzameling van alle boeken (geschreven, en ongeschreven, ongeacht hun lengte, en in welke taal dan ook)

Aftelbaarheid is belangrijk, omdat het het mogelijk maakt om elementen één voor één (en uitputtend) te bekijken of te bewerken.

>[!info] Generalisatie
>Als **A** en **B** aftelbaar zijn, dan is **A x B** ook aftelbaar

>[!col]
>De verzameling van alle breuken, $\mathbb{Q}$ , is ook aftelbaar. Immers elke breuk x/y correspondeert met een roosterpunt van (x,y) in het rooster van **Z x Z**
>
>![[zxzrooster.png]]

>[!info] Generalisatie
>Als **A** en **B** aftelbaar zijn, dan is het [[Cartesisch Product]] **A x B** dat ook

>[!info] Generalisatie
> Als $A_{1},\dots,A_{n}$ aftelbaar zijn, dan is het *eindig* [[Cartesisch Product]] $A_{1} \text{x} \dots \text{x} A_{n}$ dat ook

>[!info] Generalisatie
>Als $A_{1},...,A_{n},...$ een aftelbare rij is van aftelbare verzamelingen, dan is de aftelbare vereniging $A_{1} \cup...\cup A_{n} ...$ ook aftelbaar.

Gerelateerd: [[Oneindigheid]], [[Overaftelbaar]]

