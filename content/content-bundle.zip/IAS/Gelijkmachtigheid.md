---
tags: note
---
>[!abstract] Definitie
>Twee verzamelingen heten [[Gelijkmachtigheid|gelijkmachtig]] als er een [[Bijectie|bijectie]] tussen deze twee bestaat

Gelijkmachtigheid betekent dus eigenlijk, dat de verzamelingen even groot zijn. Als de verzamelingen dus oneindig zijn, hebben ze dezelfde [[Oneindigheid]].

Alle [[Aftelbaar|aftelbare]] verzamelingen zijn gelijkmachtig met de verzameling van natuurlijke getallen, $\mathbb{N}$.

Een manier om erachter te komen of twee verzameling gelijkmachtig zijn, is met de [[Stelling van Schröder-Bernstein]].