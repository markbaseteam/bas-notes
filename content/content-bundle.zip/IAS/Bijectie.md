---
tags: note
---
>[!abstract] Definitie
>Een functie $f$ is [[Bijectie|bijectief]] als hij aan twee voorwaarden voldoet:
>1. De functie is [[Injectie|injectief]]
>2. De functie is [[Surjectie|surjectief]]