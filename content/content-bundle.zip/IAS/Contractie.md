---
tags: note
---
>[!abstract] Definitie
>Een contractie is een afbeelding $f$ van een [[Metrische Ruimte|metrische ruimte]] $X$ naar zichzelf, zodanig dat er een $x\leq c\leq 1$ bestaat, zodat voor elk tweetal elementen $x,y \in X$ geldt dat $d(f(x),f(y)\leq c\cdot d(x,y)$

