---
tags: note
---
>[!abstract] Definitie
>Elk domein waarop je een notie van afstand kunt definiëren

