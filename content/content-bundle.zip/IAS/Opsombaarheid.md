---
tags: note
---
>[!abstract] Definitie
>Een verzameling getallen $X \subseteq \mathbb{N}$ heet [[Opsombaarheid|opsombaar]] als er een computerprogramma bestaat dat alle elementen van $X$ (vroeg of laat) afdrukt.

Gerelateerd: [[Complementair opsombaarheid]]
